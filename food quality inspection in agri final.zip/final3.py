

import cv2
import numpy as np

def calculate_sharpness(image):
    # Sharpness via Laplacian variance (high variance = sharp image)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    sharpness = laplacian.var()
    return sharpness

def calculate_color_variance(image):
    # Convert to HSV and calculate variance in saturation
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    color_var = np.var(s)
    return color_var

def classify_fruit(sharpness, color_var):
    if sharpness < 30 or color_var > 0.045:
        return "Reject", (0, 0, 255)        # Red
    elif sharpness > 80 and color_var < 0.01:
        return "Premium", (0, 255, 0)       # Green
    else:
        return "Acceptable", (0, 255, 255)  # Yellow

def process_image(image_path):
    image = cv2.imread(image_path)
    image = cv2.resize(image, (300, 300))

    sharpness = calculate_sharpness(image)
    color_var = calculate_color_variance(image)

    label, color = classify_fruit(sharpness, color_var)

    # Draw result
    output = image.copy()
    cv2.putText(output, label, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
    cv2.imshow("Classification", output)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    print(f"Sharpness: {sharpness:.2f}, Color Variance: {color_var:.2f}, Label: {label}")

# 🧪 Example usage
process_image("tomato.jpg")  # Replace with your image path
